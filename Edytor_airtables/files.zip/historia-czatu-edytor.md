# Historia czatu i stan projektu — Edytor tablic odlotów

> Dokument do wznowienia pracy. Zawiera podsumowanie rozmowy, listę zmian
> oraz notatki techniczne pozwalające kontynuować edycję narzędzia.

**Plik narzędzia:** `edytor-rozkladow.html` (samodzielny, działa offline)
**Język UI:** polski
**Kontekst:** narzędzie do offline'owej edycji tabel „Rozkłady lotów" ze strony Coral Travel
(`coraltravel.pl`) i generowania kodu HTML zgodnego z oryginałem.

---

## 1. Pierwotne zadanie

Na podstawie wklejonego fragmentu HTML strony „Rozkłady lotów" (dwie tabele:
**Lotniska** i **Linie lotnicze**) przygotować narzędzie do uzupełniania tabeli
offline. Kod wynikowy ma być **zgodny z oryginałem**.

Kluczowy format wiersza z oryginału, który MUSI być zachowany przy generowaniu:

```html
<tr>
    <td>Polska</td>
    <td>Gdańsk</td>
    <td>Gdańsk Airport</td>
    <td>GDN</td>
    <td class="none"><a href="…" rel="nofollow" target="_BLANK"><i class="bi bi-arrow-right-circle-fill"></i></a><br></td>
</tr>
```

Wymagania zgodności:
- klasa `td.none`, atrybuty `rel="nofollow"`, `target="_BLANK"`, ikona `bi bi-arrow-right-circle-fill`
- znak `&` w adresach URL zamieniany na `&amp;` (jak w oryginale, np. linki Wiedeń/Doha/Rzym)
- w pełnej tabeli zachowany oryginalny (literówkowy) atrybut `cellspaccing` oraz `id`
  (`tablice_odlotow` / `linie_lotnicze`) i nagłówek `<thead class="table-dark">`
- nagłówek kolumny linii w oryginale brzmi „Nazwa **lini**" (literówka zachowana w danych)

---

## 2. Lista zmian (chronologicznie)

1. **Wersja pierwsza** — narzędzie z dwiema zakładkami, wstępnie wypełnione danymi
   z oryginału (28 lotnisk, 23 linie). Edycja w komórkach, dodawanie/usuwanie/
   duplikowanie, sortowanie strzałkami i przeciąganiem, autozapis, generowanie kodu,
   kopiowanie, pobieranie, import HTML (wtedy w modalu).
2. **Kolorystyka → szarości w stylu shadcn/ui** oraz **import jako wklejana textarea**
   na stronie (inline, rozwijana po kliknięciu) zamiast okna „z pliku".
3. **Poprawka błędu składni JS** (niedopasowany cudzysłów w komunikacie pustej tabeli),
   **usunięcie zbędnych komunikatów/opisów** (plakietka „Działa offline", podtytuł,
   stopka, podpowiedź pod kodem), **zmiana tytułu** na „AirTables / Linie Lotnicze".
4. **Kod wynikowy = cała tabela** ustawiony jako domyślny (checkbox „Pełna tabela"
   zaznaczony na starcie).
5. **Kod wynikowy w modalu** otwieranym przyciskiem „⧉ Generuj kod HTML" nad tabelą
   (zamiast stałego bloku na dole strony). Zamykanie: ✕ / Esc / kliknięcie w tło.
6. **Pole „Wklej kod" przeniesione do modala** (jeden wspólny modal, import do aktywnej
   zakładki). **Zakładka przemianowana z „AirTables" na „Lotniska"** (druga: „Linie Lotnicze").

> Uwaga: nagłówek strony (`<title>` i `<h1>`) pozostał jako „AirTables / Linie Lotnicze".
> Etykiety zakładek to „Lotniska" i „Linie Lotnicze".

---

## 3. Aktualny stan funkcjonalny

- Dwie zakładki (segmentowany przełącznik shadcn): **Lotniska** / **Linie Lotnicze**.
- Edycja inline w komórkach (Kraj/Nazwa linii, Miasto, Lotnisko, IATA, Link href).
- Operacje na wierszach: dodaj, usuń, duplikuj, przesuń ↑/↓, **drag & drop** za numer wiersza.
- Filtr wierszy (pole „Filtruj wiersze…"). Podczas filtrowania drag jest wyłączony.
- Autozapis do `localStorage` (klucz `coral_timetable_editor_v1`) z bezpiecznym fallbackiem
  do pamięci, gdy storage niedostępny.
- „↺ Przywróć oryginał" — reset danej zakładki do danych wbudowanych (`ORIGINAL`).
- **Modal kodu** („⧉ Generuj kod HTML"): opcja „Pełna tabela" (domyślnie wł.),
  Kopiuj, Pobierz .html. Generuje dla aktywnej zakładki.
- **Modal importu** („⤓ Wklej kod"): wklejasz `<tbody>` lub całą tabelę → parsowanie →
  zastąpienie wierszy aktywnej zakładki.

---

## 4. Notatki techniczne (mapa kodu)

Wszystko w jednym pliku `edytor-rozkladow.html` (HTML + CSS + JS, bez zależności zewn.).

**Dane / konfiguracja:**
- `ORIGINAL` — obiekt `{airports:[...], airlines:[...]}`; każdy wiersz to tablica
  `[kol1, kol2, kol3, IATA, URL]`.
- `TABLE_META` — `id` tabeli oraz nagłówki kolumn dla każdej zakładki
  (uwaga: „Nazwa lini" celowo z literówką).
- `STORAGE_KEY = "coral_timetable_editor_v1"`.
- `state` — bieżące dane (kopia `ORIGINAL` lub odczyt z localStorage).

**Najważniejsze funkcje JS:**
- `renderTable(tab)` — rysuje edytowalną siatkę dla zakładki.
- `move/dup/del/addRow(tab,...)` — operacje na wierszach.
- `onDragStart/onDrop` — drag & drop kolejności.
- `escText` / `escAttr` — escaping (m.in. `&` → `&amp;`).
- `rowHTML(row)` — pojedynczy `<tr>` w formacie oryginału (wcięcia `I`/`I2`).
- `tbodyHTML(tab)` / `fullTableHTML(tab)` — generowanie zawartości tbody albo całej tabeli.
- `generate()` — wypełnia `#output` (czyta checkbox `#opt-full`).
- `openCode/closeCode` — modal kodu (`#code-modal`).
- `openImport/closeImport/doImport` — modal importu (`#import-modal`, pole `#import-text`).
- `copyOut/downloadOut/resetTab` / `toast` / `switchTab`.

**Kluczowe identyfikatory / selektory:**
- Zakładki: `.tab[data-tab="airports|airlines"]`; liczniki `#cnt-airports` / `#cnt-airlines`.
- Siatki: `tbody[data-rows="airports|airlines"]`; filtr `input[data-search="..."]`.
- Przyciski: `[data-add]`, `[data-reset]`, `[data-importtoggle]`, `#open-code`.
- Modal kodu: `#code-modal`, `#code-close`, `#opt-full`, `#output`, `#btn-copy`, `#btn-download`.
- Modal importu: `#import-modal`, `#import-close`, `#import-cancel`, `#import-do`, `#import-text`.

**Wcięcia generowanego kodu:** stałe `I` (28 spacji, `<tr>`) i `I2` (32 spacje, `<td>`).
W `fullTableHTML` wcięcia są normalizowane do poziomu wewnątrz `<table>`.

---

## 5. Pomysły / możliwe dalsze kroki

- Eksport/import całego stanu jako JSON (kopia zapasowa obu zakładek naraz).
- Walidacja kodów IATA (3 wielkie litery) i poprawności URL.
- Generowanie obu tabel jednocześnie / cała sekcja strony.
- Ujednolicenie `<title>`/`<h1>` z etykietami zakładek (jeśli pożądane).
- Sortowanie kolumn w edytorze (np. po kraju), niezależnie od `Tablesort` na docelowej stronie.

---

## 6. Dane wbudowane (na wypadek odtworzenia)

**Lotniska (airports)** — 28 pozycji, format `[Kraj, Miasto, Lotnisko, IATA, URL]`.
**Linie (airlines)** — 23 pozycje, format `[Nazwa linii, Miasto, Lotnisko, IATA, URL]`.
Pełne wartości znajdują się w obiekcie `ORIGINAL` w pliku narzędzia (sekcja na początku `<script>`).
